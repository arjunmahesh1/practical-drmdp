# What To Add To The Results Section

The added environments change the paper from a two-task clipping study into an account of distinct robustness effects. Lead with ANYmal PPO, Ant TD3 and Drawer SAC; use Drawer TD3 to show why reliability and return cannot share one verdict. Keep the older Walker and HalfCheetah examples as mechanisms and comparator-sensitive cases, not the whole empirical claim.

## Evidence And Limits

The audit covers 43 catalog cohorts, 297 named-reference comparisons, and 179 nonarchived active-setting comparisons against ordinary standard. Three archived custom-support/context cohorts remain opt-in. There are 40 nonarchived cohorts. Supplied Pendulum matrices remain in their existing reports and are not included in these counts.

Among those 179 comparisons, 13 reach L3 for reliability, 18 for catastrophe, and 12 for consistency under their own rules. These counts overlap, include post-hoc selection, and are not counts of independent discoveries. 53 profiles change in at least one vertex under paired versus independent sensitivity. Do not use this count to override the experimental design.

Every point is a trained-policy episode mean. No episode, checkpoint or cluster data was read for this audit. All 125,823 original curve arithmetic checks matched (maximum absolute error 3.64e-12); 168 independently reconstructed bootstrap interval endpoints matched within 3.42e-13. No original curve or video was replaced.

Positive results are pointwise exploratory signals, not familywise or false-discovery-rate-controlled confirmatory significance. The current caps, bands, scopes and references were viewed after seeing results. Without a prespecified selection family there is no defensible single adjusted-significance leaderboard. Native physical-success and update-activation claims require their own evidence.

## Recommended Main Findings

### 1. Lead with ANYmal PPO and Ant TD3, not only Walker and HalfCheetah
ANYmal PPO cap 1.5: suite reliability change 11.044 [7.079, 14.949] percentage points; catastrophe change -11.204 [-15.324, -7.130] pp. Ant TD3 cap 35: reliability 4.006 [1.284, 6.922] pp. Both pass all five suite dimensions when the band vertex is degraded; both also pass each of the three bands separately.

These are post-hoc, pointwise signals over the tested suites. Severe-level consistency is not established: ANYmal lower W = 0.467, Ant lower W = 0.200. Training-update activation and physical success are not certified by this audit.

### 2. Drawer SAC distinguishes reliability gains from catastrophe rescue
Cap 20: mean-return change 14.583 [6.254, 24.637]; reliability 15.613 [6.942, 26.169] pp; catastrophe -10.340 [-22.925, -0.748] pp. Cap 24 also improves mean and reliability (11.749 [2.472, 22.670] pp), but its catastrophe interval crosses zero (-6.327 [-19.728, 6.054] pp).

Cap 20 does not establish a full-suite failure-band AUC gain even though the fixed catastrophe threshold improves. Nominal training failures are 0/30 versus 3/30; much of the aggregate improvement may reflect better nominal learning. Among each method's own competent subset, shifted failure is descriptively 2.245% versus 2.872%, not an established causal difference. Both settings win 48/49 levels, but neither beats standard on the one severe level.

### 3. Use Drawer TD3 as the counterexample that motivates five separate axes
Cap 12 improves suite reliability by 3.161 [0.173, 7.295] pp and reduces catastrophe by -1.633 [-4.354, -0.136] pp, while mean return changes by -4.790 [-9.377, -0.011]. The return guardrail fails even though reliability and consistency reach L3.

This is a trade-off, not an overall robust policy. Capping retained return at one prevents higher-return policies from compensating for failures; the native mean and capped metric can therefore move in opposite directions.

### 4. The new PickCube PPO result is threshold-specific, not a general reliability win
Joint-delta PPO cap 4 has suite catastrophe change -0.741 [-1.296, -0.278] pp, while reliability change 0.222 [-0.310, 0.742] pp and mean change 0.118 [-0.108, 0.341] include zero. Mean noninferiority passes; strict mean improvement does not.

Do not replace this cohort with the older translation-controller PickCube study. The result is small and threshold-specific; it needs threshold sensitivity and independent confirmation before a broad failure-avoidance claim.

### 5. For PickCube TD3-KL, distinguish recipe gains from the KL increment
Beta 3 versus the older standard: reliability 5.904 [3.926, 8.161] pp (independent bootstrap). Versus the matched KL-off control: reliability 0.654 [0.321, 0.988] pp and mean 0.276 [0.126, 0.424] (paired bootstrap). The additional KL signal survives independent sensitivity, but suite consistency does not pass against KL-off.

The nominal reference changes with the comparator, so these normalized gaps must not be subtracted as a causal decomposition. Beta 10 and 30 do not establish suite AUC improvement over KL-off. The bypass itself improves over the older standard. Four failed SAC-KL slots and four failed TD3-KL slots remain NULL, not averaged.

### 6. Rewrite the old Walker TD3 headline with the exact comparator
Cap 400 versus inactive cap 500: suite reliability 4.852 [1.664, 9.271] pp. Against ordinary standard it is 0.766 [-0.915, 2.555] pp, whose interval crosses zero. The same setting therefore has a broad profile against one control, but only local reliability evidence against ordinary standard.

Cap 500 is not ordinary TD3 and is worse than ordinary standard in this saved comparison. The cap-400 result cannot be presented as a general suite reliability improvement over standard TD3.

### 7. Keep negative results and unavailable dimensions in the main narrative
Pusher nominal returns are nonpositive: mean return remains meaningful in native units, but retention-ratio reliability, catastrophe, band AUC and consistency are unavailable under the agreed convention. Unverified Pusher friction and 12 HalfCheetah TD3 localized axes cannot certify tested dynamics sensitivity. Aggressive caps can fail the nominal task.

Do not borrow native success rates to fill the pentagon, silently drop flat axes, treat incomplete 26/30 or 29/30 cohorts as full-30 results, or interpret lack of a positive interval as evidence of no effect.

## Compact Evidence Table

Each interval below is the primary design-appropriate suite interval. Reliability and catastrophe differences are percentage points. Mean changes retain native reward units. W is a percentage of measured levels, not a percentage of independent policies. The degraded band is fixed for the compact pentagon; all bands remain individually inspectable.

| Fixed setting / named comparator | Mean change [95% CI] | Reliability change, pp | Catastrophe change, pp | W, % [95% CI] | Profile: mean / reliability / catastrophe / degraded band / consistency |
|---|---:|---:|---:|---:|---|
| anymal_ppo_tv30 / tv_c1.5 vs vanilla | 4.727 [3.281, 6.198] | 11.044 [7.079, 14.949] | -11.204 [-15.324, -7.130] | 71.429 [57.143, 71.429] | L3 / L3 / L3 / L3 / L3 |
| ant_td3_tv30 / tv_c35 vs vanilla | 59.419 [1.375, 119.399] | 4.006 [1.284, 6.922] | -7.315 [-12.963, -2.500] | 85.714 [61.905, 90.476] | L3 / L3 / L3 / L3 / L3 |
| drawer_sac_tv30 / tv_c20 vs vanilla | 14.583 [6.254, 24.637] | 15.613 [6.942, 26.169] | -10.340 [-22.925, -0.748] | 97.959 [97.959, 97.959] | L3 / L3 / L3 / L3 / L3 |
| drawer_sac_tv30 / tv_c24 vs vanilla | 11.992 [3.134, 22.292] | 11.749 [2.472, 22.670] | -6.327 [-19.728, 6.054] | 97.959 [89.796, 100.000] | L3 / L3 / L1 / L3 / L3 |
| drawer_td3_tv30 / tv_c12 vs vanilla | -4.790 [-9.377, -0.011] | 3.161 [0.173, 7.295] | -1.633 [-4.354, -0.136] | 100.000 [61.224, 100.000] | 0 / L3 / L3 / L3 / L3 |
| ppo_tv_pickcube_20261028 / tv_c4 vs vanilla | 0.118 [-0.108, 0.341] | 0.222 [-0.310, 0.742] | -0.741 [-1.296, -0.278] | 61.290 [25.806, 90.323] | L3 / L1 / L3 / 0 / 0 |
| pickcube_td3_kl30 / kl_b3 vs vanilla | 3.222 [2.290, 4.264] | 5.904 [3.926, 8.161] | -3.796 [-5.231, -2.454] | 100.000 [100.000, 100.000] | L3 / L3 / L3 / L3 / L3 |
| pickcube_td3_kl30 / kl_b3 vs kl_bypass | 0.276 [0.126, 0.424] | 0.654 [0.321, 0.988] | -2.037 [-3.056, -1.065] | 48.387 [38.710, 58.065] | L3 / L3 / L3 / L3 / L2 |
| td3_tv_walker / tvc400 vs vanilla | 54.960 [-36.522, 160.313] | 0.766 [-0.915, 2.555] | -0.323 [-1.563, 0.826] | 67.266 [22.302, 89.209] | L3 / L2 / L2 / L2 / 0 |
| td3_tv_walker / tvc400 vs tvc500 | 262.753 [100.646, 469.359] | 4.852 [1.664, 9.271] | -4.409 [-10.226, -0.773] | 92.086 [79.496, 94.245] | L3 / L3 / L3 / L3 / L3 |

## Suggested Results Structure

1. State cohort, controller, full-30 coverage, nominal training failures and activation evidence before an effect claim. Keep unknown activation unknown.
2. Show the five-dimensional small multiples. Put Drawer TD3 beside Drawer SAC so the profile earns its place through an actual trade-off.
3. Present effect sizes and intervals for ANYmal PPO, Ant TD3 and Drawer SAC. Separate return noninferiority from strict improvement.
4. Decompose reliability gains into the three threshold bands. The width-weighted components add to the original gain; do not count them as additional discoveries.
5. Break consistency into mild/moderate/severe levels. State the small severe grids explicitly; suite performance is not uniform severe-shift repair.
6. Audit inactive/bypass comparators before attributing benefits to a robust update. Include the old Walker cap-500 contrast and the smaller KL-on versus KL-off increment.
7. End with scope failures: weak nominal policies under aggressive caps, nonpositive-reference Pusher metrics, incomplete settings, and unverified perturbations.

## Edits Needed In The New Framework Section

- Replace the signed return margin with -0.05 times the absolute reference mean, as confirmed by the human. Define ratio metrics only for positive R0.
- State severity boundaries explicitly: mild loss <20%, moderate 20-50% inclusive, severe >50%. Membership is fixed from observed reference medians.
- Qualify "equivalent methods produce W near 0.5". Strict ties count zero; identical clipped outcomes yield W=0. A tie-adjusted statistic would be a different statistic and was not silently substituted.
- State that L1 no-demonstrated-harm is a weaker criterion than formal noninferiority or equivalence. A CI crossing zero cannot establish parity.
- Specify that W counts levels equally whereas the other suite metrics weight axes equally. Nominal summaries average the saved nominal evaluations across axes; these repeated evaluations do not create independent training seeds.
- Rename the "failure band" interpretation carefully: band AUC integrates low thresholds and is not identical to the single threshold catastrophe rate. Drawer SAC cap20 illustrates their different verdicts.
- Name the primary paired/independent design per comparison. A sorted seed-index sensitivity is not proof of a matched design.
- Call the pentagon a metric-evidence profile, not a physical-robustness certificate. Full outer rings still require separately established competence, active updates and a validated perturbation suite.

## Figures

- `figures/fixed-setting-profiles.pdf` and PNG: six pentagons, degraded band fixed.
- `figures/suite-effects.pdf` and PNG: four effect/interval panels, fixed comparisons.
- `figures/consistency-severity.pdf` and PNG: mild/moderate/severe W with actual level counts.
- `figures/reliability-bands.pdf` and PNG: exact width-weighted decomposition of the AUC change.
- `figures/competence-deployment.pdf` and PNG: nominal learning failures versus shifted failures among each method's nominally competent subset; descriptive populations, no causal decomposition.

## Reproducibility

Source commit: c3c34daa15a714ccb47fbc886067bef582805a46. `PROTOCOL.md` fixes definitions; `analyze.py` computes all comparisons; `validate.py` reconstructs arithmetic and selected intervals independently; `test_profiles.py` covers boundary cases. `comparisons.csv` contains every scoped test and both resampling intervals. `index.json` and `outputs/` retain fixed-setting profiles and diagnostics. No policy is assembled from the best vertex across different caps.
