# Ready 30-seed return curves: Overleaf packages

Local packaging only, November 4, 2026. No new experiments, artifact collection, raw-episode reads, checkpoint reads, cluster queries or deployment.

## Downloads

[All ten comparisons](all_ready_returns_overleaf_20261104.zip)

- [Humanoid PPO-TV ](packages/ppo_tv_humanoid_overleaf_20261104.zip)
- [ANYmal PPO-TV ](packages/ppo_tv_anymal_overleaf_20261104.zip)
- [Ant TD3-TV ](packages/td3_tv_ant_overleaf_20261104.zip)
- [Drawer PPO-TV ](packages/ppo_tv_drawer_overleaf_20261104.zip)
- [PickCube SAC-KL ](packages/sac_kl_pickcube_20261028_overleaf_20261104.zip)
- [Ant SAC-TV ](packages/sac_tv_ant_overleaf_20261104.zip)
- [Pusher PPO-TV ](packages/ppo_tv_pusher_overleaf_20261104.zip)
- [Pusher SAC-TV ](packages/sac_tv_pusher_overleaf_20261104.zip)
- [Pusher TD3-TV ](packages/td3_tv_pusher_overleaf_20261104.zip)
- [Ant PPO-TV (cap 2 only) ](packages/ppo_tv_ant_overleaf_20261104.zip)

The first six are the newly requested full-30 comparisons. The Pusher comparisons and Ant PPO cap-2 comparison are also ready. Ant PPO is not a complete grid. PickCube beta 0.1/0.3 are incomplete and excluded, with four failures preserved.

## Overleaf paths

Extract the Results tree into the project root. Existing Pusher folder names are retained; these files intentionally replace the older Pusher cohort in the manuscript, not its archived source package. PickCube uses a dated folder to distinguish the end-effector-delta recipe from historical controllers. No historical source files were overwritten here. All plots retain their PDF basenames.

The unique preview_*.tex files are standalone examples, not manuscript replacements. `returns_insert.tex` inputs all ten sections; `paste_into_manuscript.tex` lists the preamble definition and individual section inputs. Full figure environments live inside each Results/ReturnAtlas/<comparison>/returns_insert.tex. `returns_full_figure_blocks.tex` is the expanded version for direct pasting instead of inputs; do not include both versions, which would duplicate figures.

Fixed ordinary standard; best complete active parameter chosen ex post by axis; thirty policy-level episode means; sample SD, not CI. Controls are not active candidates. Pusher friction effectiveness is unverified. No physical-success, significance, noninferiority or hierarchy certification follows from these plots.
