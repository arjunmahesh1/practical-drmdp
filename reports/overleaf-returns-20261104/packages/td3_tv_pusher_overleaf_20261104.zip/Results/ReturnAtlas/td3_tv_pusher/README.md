# Pusher TD3--TV

Completed settings: ordinary standard and TV cap values -28, -26, -24, -22, -20, -19, -18, -17, each with 30 training seeds (1000-1029). Contact-friction levels have identical saved per-policy returns; the effectiveness of that intervention is unverified. The active setting is selected ex post for each axis by mean return over its full grid, including nominal. This is descriptive selection, not held-out evaluation. Returns and completion alone do not certify task success or robust success.

Figure convention: fixed ordinary standard versus the best complete active setting per axis. Sample SD is not a confidence interval. Negative comparisons are retained.

Source cohort: `pusher_td3_tv30`. Existing axis PDF basenames are unchanged. Every PDF is copied byte-for-byte from the validated local gallery. `overview.pdf` is supplied separately and is not inserted into the paper.

`data/seed_accounting.csv` preserves all declared slots and failures; `data/policy_mean_returns.csv` contains only eligible complete-setting summaries. `data/best_per_axis.csv` records descriptive axis selections. The ordinary baseline is named `standard` in CSVs and Standard in plots.

Extract the Results tree at your Overleaf project root. The preview file is optional; it does not replace your manuscript main file. Use graphicx and subcaption, and define `\providecommand{\ReturnFigureRoot}{Results/ReturnAtlas}` in the preamble.

```tex
\input{Results/ReturnAtlas/td3_tv_pusher/returns_insert.tex}
```
