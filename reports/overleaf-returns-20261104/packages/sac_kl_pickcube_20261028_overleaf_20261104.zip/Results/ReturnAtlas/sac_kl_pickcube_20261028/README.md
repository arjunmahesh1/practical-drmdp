# PickCube SAC--KL

Completed settings: ordinary standard and beta values 1, 3, 10, 30, each with 30 training seeds (1000-1029). The matching end-effector-delta, 1M-transition SAC reference is fixed. The KL-off control also has 30 seeds, is shown as a separate reference curve and retained in the data, but is not an active candidate or a certified native-parity result. Beta 0.1 and 0.3 each have 28 completed and two failed seeds; neither incomplete setting is plotted. All four failures remain in seed accounting. The active setting is selected ex post for each axis by mean return over its full grid, including nominal. This is descriptive selection, not held-out evaluation. Returns and completion alone do not certify task success or robust success.

Figure convention: fixed ordinary standard versus the best complete active setting per axis. Sample SD is not a confidence interval. Negative comparisons are retained.

Source cohort: `pickcube_sac_kl30`. Existing axis PDF basenames are unchanged. Every PDF is copied byte-for-byte from the validated local gallery. `overview.pdf` is supplied separately and is not inserted into the paper.

`data/seed_accounting.csv` preserves all declared slots and failures; `data/policy_mean_returns.csv` contains only eligible complete-setting summaries. `data/best_per_axis.csv` records descriptive axis selections. The ordinary baseline is named `standard` in CSVs and Standard in plots.

Extract the Results tree at your Overleaf project root. The preview file is optional; it does not replace your manuscript main file. Use graphicx and subcaption, and define `\providecommand{\ReturnFigureRoot}{Results/ReturnAtlas}` in the preamble.

```tex
\input{Results/ReturnAtlas/sac_kl_pickcube_20261028/returns_insert.tex}
```
